from flask import Flask, request, jsonify
import json


# class book
class Book:
    counter = 1

    def __init__(self, Title, Author, Print_Year, Price, Genre):
        self.id = Book.counter
        self.title = Title
        self.author = Author
        self.print_Year = Print_Year
        self.price = Price
        self.genre = Genre
        Book.counter += 1

    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'author': self.author,
            'price': self.price,
            'year': self.print_Year,
            'genres': self.genre
        }


Genre = ["SCI_FI", "NOVEL", "HISTORY", "MANGA", "ROMANCE", "PROFESSIONAL"]
# create list of books
books = []


app = Flask(__name__)


# 1 request, Health endpoint
@app.route('/books/health', methods=['GET'])
def health():
    return "OK", 200


# 2 request create a new book
@app.route('/book', methods=['POST'])
def create_book():
    data = request.get_json()
    title = data['title']
    author = data['author']
    year = data['year']
    price = data['price']
    genres = data['genres']

    # Check if book with the same title already exists
    if any(book.title.lower() == title.lower() for book in books):
        return jsonify(errorMessage=f"Error: Book with the title [{title}] already exists in the system"), 409

    if not(1940 <= year <= 2100):
        return jsonify(errorMessage=f"Error: Can’t create new Book that its year [{year}]"
                                    f" is not in the accepted range [1940 -> 2100]"), 409

    if price <= 0:
        return jsonify(errorMessage=f"Error: Can’t create new Book with negative price"), 409

    new_book = Book(title, author, year, price, genres)
    books.append(new_book)


    for book in books:
        print("id:", book.id)
        print("Title:", book.title)
        print("Author:", book.author)
        print("Print Year:", book.print_Year)
        print("Price:", book.price)
        print("Genres:", book.genre)
        print()

    return jsonify(result=new_book.id), 200


# 3 request
@app.route('/books/total', methods=['GET'])
def get_total_books():
    # Get query parameters and if they are empty will return empty string
    author = request.args.get('author', '').lower()
    price_bigger_than = request.args.get('price-bigger-than', '')
    price_less_than = request.args.get('price-less-than', '')
    year_bigger_than = request.args.get('year-bigger-than', '')
    year_less_than = request.args.get('year-less-than', '')
    genres = request.args.get('genres', '').upper().split(',')

    # Validate genres
    if genres != ['']:
        for genre in genres:
            if genre not in Genre:
             return '', 400

    filtered_books = filter_books(author, price_bigger_than, price_less_than, year_bigger_than, year_less_than, genres)

    # Calculate total number of books after filtering
    total_books = len(filtered_books)

    for book in filtered_books:
        print("id:", book.id)
        print("Title:", book.title)
        print("Author:", book.author)
        print("Print Year:", book.print_Year)
        print("Price:", book.price)
        print("Genres:", book.genre)
        print()


    return jsonify(result=total_books), 200

# 4 request
@app.route('/books', methods=['GET'])
def get_books_data():
    # Get query parameters and if they are empty will return empty string
    author = request.args.get('author', '').lower()
    price_bigger_than = request.args.get('price-bigger-than', '')
    price_less_than = request.args.get('price-less-than', '')
    year_bigger_than = request.args.get('year-bigger-than', '')
    year_less_than = request.args.get('year-less-than', '')
    genres = request.args.get('genres', '').upper().split(',')

    # Validate genres
    if genres != ['']:
        for genre in genres:
            if genre not in Genre:
                return jsonify({}), 400

    # Filter books based on query parameters
    filtered_books = filter_books(author, price_bigger_than, price_less_than, year_bigger_than, year_less_than, genres)

    # Sort filtered books by title in ascending order
    filtered_books = sorted(filtered_books, key=lambda book: book.title.lower())

    # Convert filtered books to JSON objects
    result = [book.to_dict() for book in filtered_books]
    print("filtered books", result)

    return jsonify({"result": result}), 200
# 5 request
@app.route('/book', methods=['GET'])
def get_single_book_data():
    book_id = request.args.get('id', type=int)

    for book in books:
        if int(book_id) == int(book.id):
            print(book.to_dict())
            return jsonify({"result": book.to_dict()}), 200

    return jsonify({'errorMessage': f'Error: no such Book with id {book_id}'}), 404


# 6 request
@app.route('/book', methods=['PUT'])
def update_book_price():
    book_id = request.args.get('id')
    new_price = request.args.get('price')

    # Check if book with the given id exists
    book_to_update = None
    for book in books:
        if str(book_id) == str(book.id):
            book_to_update = book
            break

    if book_to_update is None:
        return jsonify(errorMessage=f"Error: no such Book with id {book_id}"), 404

    # Check if the new price is valid
    new_price = int(new_price)
    if new_price <= 0:
        return jsonify(errorMessage=f"Error: price update for book [{book_id}] must be a positive integer"), 409


    # Update the price of the book
    old_price = book_to_update.price
    book_to_update.price = new_price

    return jsonify(result=old_price), 200


# 7 request
@app.route('/book', methods=['DELETE'])
def delete_book():
    book_id = request.args.get('id')

    # Check if book with the given id exists
    book_to_delete = None
    for book in books:
        if str(book_id) == str(book.id):
            book_to_delete = book
            break

    if book_to_delete is None:
        return jsonify(errorMessage=f"Error: no such Book with id {book_id}"), 404

    # Remove the book from the list
    books.remove(book_to_delete)

    # Get the number of books left in the system
    num_books_left = len(books)

    return jsonify(result=num_books_left), 200


def filter_books(author, price_bigger_than, price_less_than, year_bigger_than, year_less_than, genres):
    filtered_books = books

    if author:
        filtered_books = [book for book in filtered_books if book.author.lower() == author]
    if price_bigger_than:
        filtered_books = [book for book in filtered_books if book.price >= int(price_bigger_than)]
    if price_less_than:
        filtered_books = [book for book in filtered_books if book.price <= int(price_less_than)]
    if year_bigger_than:
        filtered_books = [book for book in filtered_books if book.print_Year >= int(year_bigger_than)]
    if year_less_than:
        filtered_books = [book for book in filtered_books if book.print_Year <= int(year_less_than)]
    if genres != ['']:
        filtered_books = [book for book in filtered_books if any(genre in book.genre for genre in genres)]
    return filtered_books

if __name__ == '__main__':
    app.run(host='localhost', port=8574)
